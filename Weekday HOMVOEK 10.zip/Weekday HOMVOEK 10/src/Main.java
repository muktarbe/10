import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                Peaksoft ⌨💻🖱 то окууган
                бир жумаалык тизменизди коргунуз келеби
                Дүйшөмбү — 1
                Шейшемби — 2
                Шаршемби — 3
                Бейшемби — 4
                Жума — 5
                Ишемби — 6
                Жекшемби — 7
                """);
        int aa = scanner.nextInt();
      switch (aa){
          case 1:
              System.out.println(Weekday.Monday1.aa());
              break;
              case 2:
              System.out.println(Weekday.Tuesday2.aa());
              break;
          case 3:
              System.out.println(Weekday.Wednesday3.aa());
              break;
          case 4:
              System.out.println(Weekday.Thursday4.aa());
              break;
          case 5:
              System.out.println(Weekday.Friday5.aa());
              break;
          case 6:
              System.out.println(Weekday.Saturday6.aa());
              break;
          case 7:
              System.out.println(Weekday.Sunday7.aa());
              break;
      }
    }
}