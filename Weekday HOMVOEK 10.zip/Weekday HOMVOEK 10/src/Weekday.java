public enum Weekday {
    Monday1 {
        public String aa() {
            return " Дуйшөмбү куну жаны тема отобуз ";
        }
    },
    Tuesday2 {
        public String aa() {
            return " Шейшемби күнү откон тема бойюнча практика кылыбыз ";
        }
    },
    Wednesday3 {
        public String aa() {
            return " Шаршемби күнү англисткий сабагы болот ";
        }
    },
    Thursday4 {
        public String aa() {
            return " Бейшемби күнү кайталоо ";
        }
    },
    Friday5 {
        public String aa() {
            return " Жума күнү практика ";
        }
    },
    Saturday6 {
        public String aa() {
            return " Ишемби күнү тушунбой калган темалар \nбойунча сууро жоп ";
        }
    },
    Sunday7 {
        public String aa() {
            return " Жекшемби  дем алыш ";
        }
    };

    public abstract String aa();
}




